import Component from '@glimmer/component';
export default class NewsItemComponent extends Component {}