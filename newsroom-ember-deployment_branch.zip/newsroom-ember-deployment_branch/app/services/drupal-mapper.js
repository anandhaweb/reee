import DrupalMapper from 'ember-data-drupal/services/drupal-mapper';

export default DrupalMapper;