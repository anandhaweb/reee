import Service from '@ember/service';

export default Service.extend({
  breadcrumbsLinks: null,
});
